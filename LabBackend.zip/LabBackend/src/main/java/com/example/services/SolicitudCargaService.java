package com.example.services;

import com.example.PersistenceManager;
import com.example.models.PropietarioCarga;
import com.example.models.SolicitudCarga;
import com.example.models.SolicitudCargaDTO;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/solicitudesCarga")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SolicitudCargaService {

    private EntityManager entityManager;

    @PostConstruct
    public void init() {
        entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
    }

    @GET
    @Path("/obtener")
    public Response obtenerSolicitudes() {
        Query query = entityManager.createQuery("SELECT s FROM SolicitudCarga s ORDER BY s.fecha DESC");
        List<SolicitudCarga> solicitudes = query.getResultList();
        return Response.ok(solicitudes).build();
    }

    @POST
    @Path("/agregar")
    public Response agregarSolicitud(SolicitudCargaDTO solicitudCargaDTO) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            SolicitudCarga solicitud = new SolicitudCarga();

            solicitud.setFecha(solicitudCargaDTO.getFecha());
            solicitud.setOrigen(solicitudCargaDTO.getOrigen());
            solicitud.setDestino(solicitudCargaDTO.getDestino());
            solicitud.setDimensiones(solicitudCargaDTO.getDimensiones());
            solicitud.setPeso(solicitudCargaDTO.getPeso());
            solicitud.setValorAsegurado(solicitudCargaDTO.getValorAsegurado());
            solicitud.setEmpaque(solicitudCargaDTO.getEmpaque());

            if (solicitudCargaDTO.getPropietarioCarga() == null) {
                PropietarioCarga propietarioCarga = new PropietarioCarga();
                propietarioCarga.setNombre(solicitudCargaDTO.getPropietarioCarga().getNombre());
                propietarioCarga.setCorreo(solicitudCargaDTO.getPropietarioCarga().getCorreo());
                propietarioCarga.setTelefono(solicitudCargaDTO.getPropietarioCarga().getTelefono());
                propietarioCarga.setDireccion(solicitudCargaDTO.getPropietarioCarga().getDireccion());
                propietarioCarga.setContraseña(solicitudCargaDTO.getPropietarioCarga().getContraseña());
                solicitud.setPropietarioCarga(propietarioCarga);
            }
            
            entityManager.persist(solicitud);
            transaction.commit();
            return Response.status(Response.Status.CREATED).entity(solicitud.getId()).build();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error al agregar la solicitud").build();
        }
    }

    @PUT
    @Path("/actualizar/{id}")
    public Response actualizarSolicitud(@PathParam("id") String id, SolicitudCargaDTO solicitudCargaDTO) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            SolicitudCarga solicitud = entityManager.find(SolicitudCarga.class, id);
            if (solicitud == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Solicitud no encontrada").build();
            }
            transaction.begin();

            solicitud.setFecha(solicitudCargaDTO.getFecha());
            solicitud.setOrigen(solicitudCargaDTO.getOrigen());
            solicitud.setDestino(solicitudCargaDTO.getDestino());
            solicitud.setDimensiones(solicitudCargaDTO.getDimensiones());
            solicitud.setPeso(solicitudCargaDTO.getPeso());
            solicitud.setValorAsegurado(solicitudCargaDTO.getValorAsegurado());
            solicitud.setEmpaque(solicitudCargaDTO.getEmpaque());

            if (solicitudCargaDTO.getPropietarioCarga() != null) {
                PropietarioCarga propietarioCarga = solicitud.getPropietarioCarga();
                propietarioCarga.setNombre(solicitudCargaDTO.getPropietarioCarga().getNombre());
                propietarioCarga.setCorreo(solicitudCargaDTO.getPropietarioCarga().getCorreo());
                propietarioCarga.setTelefono(solicitudCargaDTO.getPropietarioCarga().getTelefono());
                propietarioCarga.setDireccion(solicitudCargaDTO.getPropietarioCarga().getDireccion());
                propietarioCarga.setContraseña(solicitudCargaDTO.getPropietarioCarga().getContraseña());
            }

            entityManager.merge(solicitud);
            transaction.commit();
            return Response.ok().entity("Solicitud actualizada correctamente").build();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error al actualizar la solicitud").build();
        }
    }

    @DELETE
    @Path("/eliminar/{id}")
    public Response eliminarSolicitud(@PathParam("id") String id) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            SolicitudCarga solicitud = entityManager.find(SolicitudCarga.class, id);
            if (solicitud == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Solicitud no encontrada").build();
            }
            transaction.begin();
            entityManager.remove(solicitud);
            transaction.commit();
            return Response.ok().entity("Solicitud eliminada correctamente").build();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error al eliminar la solicitud").build();
        }
    }

    @OPTIONS
    @Path("{path : .*}")
    public Response options() {
        return Response.ok()
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
                .header("Access-Control-Allow-Headers", "Content-Type")
                .build();
    }
}
